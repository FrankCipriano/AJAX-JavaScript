-- Generado por Oracle SQL Developer Data Modeler 4.0.3.853
--   en:        2015-04-17 19:18:40 CST
--   sitio:      Oracle Database 11g
--   tipo:      Oracle Database 11g




DROP TABLE C_Articulo CASCADE CONSTRAINTS ;

DROP TABLE C_Categoría CASCADE CONSTRAINTS ;

DROP TABLE C_Foto CASCADE CONSTRAINTS ;

DROP TABLE C_Perfil CASCADE CONSTRAINTS ;

DROP TABLE C_Usuario CASCADE CONSTRAINTS ;

DROP TABLE C_Votos CASCADE CONSTRAINTS ;

CREATE TABLE C_Articulo
  (
    id     INTEGER NOT NULL ,
    Titulo VARCHAR2 (45) ,
    Contenido CLOB ,
    FechaCreacion  DATE ,
    C_Categoría_id INTEGER NOT NULL ,
    C_Usuario_id   INTEGER NOT NULL
  ) ;
ALTER TABLE C_Articulo ADD CONSTRAINT C_Articulo_PK PRIMARY KEY ( id ) ;

CREATE TABLE C_Categoría
  ( id INTEGER NOT NULL , Categoria VARCHAR2 (45)
  ) ;
ALTER TABLE C_Categoría ADD CONSTRAINT C_Categoría_PK PRIMARY KEY ( id ) ;

CREATE TABLE C_Foto
  (
    id            INTEGER NOT NULL ,
    path          VARCHAR2 (255) ,
    C_Articulo_id INTEGER NOT NULL
  ) ;
ALTER TABLE C_Foto ADD CONSTRAINT C_Foto_PK PRIMARY KEY ( id ) ;

CREATE TABLE C_Perfil
  (
    id           INTEGER NOT NULL ,
    Nombre       VARCHAR2 (45) ,
    Apellido     VARCHAR2 (45) ,
    Pais         VARCHAR2 (45) ,
    Direccion    VARCHAR2 (45) ,
    C_Usuario_id INTEGER NOT NULL
  ) ;
ALTER TABLE C_Perfil ADD CONSTRAINT C_Perfil_PK PRIMARY KEY ( id ) ;

CREATE TABLE C_Usuario
  (
    id            INTEGER NOT NULL ,
    usuario       VARCHAR2 (45) ,
    password      VARCHAR2 (45) ,
    fechacreacion DATE
  ) ;
ALTER TABLE C_Usuario ADD CONSTRAINT C_Usuario_PK PRIMARY KEY ( id ) ;

CREATE TABLE C_Votos
  (
    id            INTEGER NOT NULL ,
    C_Usuario_id  INTEGER NOT NULL ,
    C_Articulo_id INTEGER NOT NULL
  ) ;
ALTER TABLE C_Votos ADD CONSTRAINT C_Votos_PK PRIMARY KEY ( id ) ;

ALTER TABLE C_Articulo ADD CONSTRAINT C_Articulo_C_Categoría_FK FOREIGN KEY ( C_Categoría_id ) REFERENCES C_Categoría ( id ) ;

ALTER TABLE C_Articulo ADD CONSTRAINT C_Articulo_C_Usuario_FK FOREIGN KEY ( C_Usuario_id ) REFERENCES C_Usuario ( id ) ;

ALTER TABLE C_Foto ADD CONSTRAINT C_Foto_C_Articulo_FK FOREIGN KEY ( C_Articulo_id ) REFERENCES C_Articulo ( id ) ;

ALTER TABLE C_Perfil ADD CONSTRAINT C_Perfil_C_Usuario_FK FOREIGN KEY ( C_Usuario_id ) REFERENCES C_Usuario ( id ) ;

ALTER TABLE C_Votos ADD CONSTRAINT C_Votos_C_Articulo_FK FOREIGN KEY ( C_Articulo_id ) REFERENCES C_Articulo ( id ) ;

ALTER TABLE C_Votos ADD CONSTRAINT C_Votos_C_Usuario_FK FOREIGN KEY ( C_Usuario_id ) REFERENCES C_Usuario ( id ) ;


-- Informe de Resumen de Oracle SQL Developer Data Modeler: 
-- 
-- CREATE TABLE                             6
-- CREATE INDEX                             0
-- ALTER TABLE                             12
-- CREATE VIEW                              0
-- CREATE PACKAGE                           0
-- CREATE PACKAGE BODY                      0
-- CREATE PROCEDURE                         0
-- CREATE FUNCTION                          0
-- CREATE TRIGGER                           0
-- ALTER TRIGGER                            0
-- CREATE COLLECTION TYPE                   0
-- CREATE STRUCTURED TYPE                   0
-- CREATE STRUCTURED TYPE BODY              0
-- CREATE CLUSTER                           0
-- CREATE CONTEXT                           0
-- CREATE DATABASE                          0
-- CREATE DIMENSION                         0
-- CREATE DIRECTORY                         0
-- CREATE DISK GROUP                        0
-- CREATE ROLE                              0
-- CREATE ROLLBACK SEGMENT                  0
-- CREATE SEQUENCE                          0
-- CREATE MATERIALIZED VIEW                 0
-- CREATE SYNONYM                           0
-- CREATE TABLESPACE                        0
-- CREATE USER                              0
-- 
-- DROP TABLESPACE                          0
-- DROP DATABASE                            0
-- 
-- REDACTION POLICY                         0
-- 
-- ERRORS                                   0
-- WARNINGS                                 0
